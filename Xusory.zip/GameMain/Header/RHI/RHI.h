#pragma once

#include "DirectX/Common/d3dx12.h"
#include "DirectX/Common/DxDefine.h"
#include "DirectX/Common/DxInclude.h"
#include "DirectX/Common/DxObject.h"

#include "DirectX/Dx12/Dx12Device.h"

#include "DirectX/DxFactory.h"
#include "DirectX/DxManager.h"
