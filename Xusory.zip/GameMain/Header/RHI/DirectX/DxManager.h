#pragma once

#include "../IGraphicsManager.h"

#include "DX12/Dx12Device.h"
#include "DX12/Dx12RootSignature.h"
#include "DxFactory.h"

namespace XusoryEngine
{
	class DxManager : public IGraphicsManager
	{
	public:
		DxManager();
		DELETE_COPY_OPERATOR(DxManager);
		DELETE_MOVE_OPERATOR(DxManager);
		~DxManager() override;

		void InitGraphicsObject(const void* renderWindow) override;
		void Resize(UINT width, UINT height) override;
		void Render() override;

	private:
		void CreateDevice();
		void CreateCommonRootSignature();

		DxFactory* m_factory = nullptr;
		Dx12Device* m_dx12Device = nullptr;

		Dx12RootSignature* m_commonRootSignature = nullptr;
	};
}
