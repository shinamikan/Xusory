#include "../DxManager.h"

namespace XusoryEngine
{
	DxManager::DxManager() : IGraphicsManager(GraphicsLibrary::DirectX12) { }


	DxManager::~DxManager()
	{
		delete m_factory;
		delete m_dx12Device;
		delete m_commonRootSignature;
	}

	void DxManager::InitGraphicsObject(const void* renderWindow)
	{
		CreateDevice();
		CreateCommonRootSignature();
	}

	void DxManager::Resize(UINT width, UINT height)
	{
		
	}

	void DxManager::Render()
	{
		
	}

	void DxManager::CreateDevice()
	{
		m_factory = new DxFactory;
		m_dx12Device = new Dx12Device;

		m_factory->Create();
		m_dx12Device->Create(m_factory);
	}

	void DxManager::CreateCommonRootSignature()
	{
		m_commonRootSignature = new Dx12RootSignature;
		//m_commonRootSignature.AddDescriptorRange(D3D12_DESCRIPTOR_RANGE_TYPE_SRV, 1, 0);
		m_commonRootSignature->AddConstantBufferView(0);
		m_commonRootSignature->Create(m_dx12Device);
	}

}
