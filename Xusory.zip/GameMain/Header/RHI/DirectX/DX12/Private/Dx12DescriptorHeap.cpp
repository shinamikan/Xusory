#include "../Dx12DescriptorHeap.h"
#include "../Dx12Device.h"

namespace XusoryEngine
{
    Dx12DescriptorHandle::Dx12DescriptorHandle(D3D12_CPU_DESCRIPTOR_HANDLE cpuHandle) : m_cpuHandle(cpuHandle) { }
    Dx12DescriptorHandle::Dx12DescriptorHandle(D3D12_CPU_DESCRIPTOR_HANDLE cpuHandle, D3D12_GPU_DESCRIPTOR_HANDLE gpuHandle)
        : m_cpuHandle(cpuHandle), m_gpuHandle(gpuHandle){ }

    const D3D12_CPU_DESCRIPTOR_HANDLE& Dx12DescriptorHandle::GetCpuDescriptorHandle() const
    {
        return m_cpuHandle;
    }

    const D3D12_GPU_DESCRIPTOR_HANDLE& Dx12DescriptorHandle::GetGpuDescriptorHandle() const
    {
        return m_gpuHandle;
    }

    D3D12_CPU_DESCRIPTOR_PTR Dx12DescriptorHandle::GetCpuDescriptorHandlePtr() const
    {
        return m_cpuHandle.ptr;
    }

    D3D12_GPU_DESCRIPTOR_PTR Dx12DescriptorHandle::GetGpuDescriptorHandlePtr() const
    {
        return m_gpuHandle.ptr;
    }

    BOOL Dx12DescriptorHandle::IsShaderVisible() const
    {
        return m_gpuHandle.ptr != NULL;
    }

    Dx12DescriptorHandle Dx12DescriptorHandle::operator+(INT scaledByDescriptorSize) const
    {
        Dx12DescriptorHandle handle = *this;
        handle += scaledByDescriptorSize;
        return handle;
    }

    void Dx12DescriptorHandle::operator+=(INT scaledByDescriptorSize)
    {
        Offset(scaledByDescriptorSize);
    }

    void Dx12DescriptorHandle::Offset(INT scaledByDescriptorSize)
    {
        m_cpuHandle.ptr += scaledByDescriptorSize;
        if (IsShaderVisible())
        {
            m_gpuHandle.ptr += scaledByDescriptorSize;
        }
    }

    Dx12DescriptorHeap::Dx12DescriptorHeap(D3D12_DESCRIPTOR_HEAP_TYPE descHeapType, BOOL shaderVisible) :
		m_descHeapType(descHeapType), m_shaderVisible(shaderVisible) { }

    void Dx12DescriptorHeap::Create(const Dx12Device* device, UINT heapSize)
    {
        D3D12_DESCRIPTOR_HEAP_DESC heapDesc;
        heapDesc.Type = m_descHeapType;
        heapDesc.NumDescriptors = heapSize;
        heapDesc.Flags = static_cast<D3D12_DESCRIPTOR_HEAP_FLAGS>(m_shaderVisible);
        heapDesc.NodeMask = 0;
        ThrowIfDxFailed((*device)->CreateDescriptorHeap(&heapDesc, IID_PPV_ARGS(GetDxObjectAddressOf())));

        m_heapSize = heapSize;
        m_descriptorSize = (*device)->GetDescriptorHandleIncrementSize(heapDesc.Type);
        m_descriptorAllocatedList.resize(heapSize);
        m_firstDescriptorHandle.m_cpuHandle = (*this)->GetCPUDescriptorHandleForHeapStart();
        if (m_shaderVisible)
        {
            m_firstDescriptorHandle.m_gpuHandle = (*this)->GetGPUDescriptorHandleForHeapStart();
        }
    }

    D3D12_DESCRIPTOR_HEAP_TYPE Dx12DescriptorHeap::GetHeapType() const
    {
        return m_descHeapType;
    }

    BOOL Dx12DescriptorHeap::GetShaderVisible() const
    {
        return m_shaderVisible;
    }

    UINT Dx12DescriptorHeap::GetHeapSize() const
    {
        return m_heapSize;
    }

    UINT Dx12DescriptorHeap::GetDescriptorSize() const
    {
        return m_descriptorSize;
    }

    UINT Dx12DescriptorHeap::GetNumOfDescriptors() const
    {
        return m_descriptorNum;
    }

    UINT Dx12DescriptorHeap::GetNumOfFreeSlots() const
    {
        return m_heapSize - m_descriptorNum;
    }

    BOOL Dx12DescriptorHeap::GetDescriptorAllocated(UINT index) const
    {
        return m_descriptorAllocatedList.at(index);
    }


    UINT Dx12DescriptorHeap::Exist(const Dx12DescriptorHandle& handle) const
    {
	    
    }


    void Dx12DescriptorHeap::ReSet()
    {
        DxObject::ReSet();
        m_heapSize = 0;
        m_descriptorSize = 0;
        m_descriptorAllocatedList.clear();
        m_firstDescriptorHandle = Dx12DescriptorHandle();
    }

}
