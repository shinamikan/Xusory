#pragma once

#pragma once

#include "../Common/PlatformDefine.h"

namespace XusoryEngine
{
	DLL_CLASS(Internet)
	{

	};
}

