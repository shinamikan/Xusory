#pragma once

#include "../Common/PlatformDefine.h"

namespace XusoryEngine
{
	DLL_CLASS(Socket)
	{

	};
}
