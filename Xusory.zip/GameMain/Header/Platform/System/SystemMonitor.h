#pragma once

#include "../Common/PlatformDefine.h"

namespace XusoryEngine
{
	
}
