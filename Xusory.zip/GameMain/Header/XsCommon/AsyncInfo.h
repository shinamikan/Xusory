#pragma once
#include <iostream>

struct AsyncInfo
{
	float process;
	std::string info;
};
