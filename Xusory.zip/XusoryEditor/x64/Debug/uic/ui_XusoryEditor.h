/********************************************************************************
** Form generated from reading UI file 'XusoryEditor.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_XUSORYEDITOR_H
#define UI_XUSORYEDITOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_XusoryEditorClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *XusoryEditorClass)
    {
        if (XusoryEditorClass->objectName().isEmpty())
            XusoryEditorClass->setObjectName(QString::fromUtf8("XusoryEditorClass"));
        XusoryEditorClass->resize(600, 400);
        menuBar = new QMenuBar(XusoryEditorClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        XusoryEditorClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(XusoryEditorClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        XusoryEditorClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(XusoryEditorClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        XusoryEditorClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(XusoryEditorClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        XusoryEditorClass->setStatusBar(statusBar);

        retranslateUi(XusoryEditorClass);

        QMetaObject::connectSlotsByName(XusoryEditorClass);
    } // setupUi

    void retranslateUi(QMainWindow *XusoryEditorClass)
    {
        XusoryEditorClass->setWindowTitle(QCoreApplication::translate("XusoryEditorClass", "XusoryEditor", nullptr));
    } // retranslateUi

};

namespace Ui {
    class XusoryEditorClass: public Ui_XusoryEditorClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_XUSORYEDITOR_H
