#include "XusoryEditor.h"

XusoryEditor::XusoryEditor(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

XusoryEditor::~XusoryEditor()
{}
